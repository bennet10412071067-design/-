-- Run this entire script in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'member' check (role in ('admin','member')),
  created_at timestamptz not null default now()
);

create table if not exists public.members (
  id uuid primary key default gen_random_uuid(),
  member_no text not null unique,
  auth_user_id uuid unique references auth.users(id) on delete set null,
  name text not null,
  phone text not null,
  birth_date date,
  plan text not null check (plan in ('lifetime','annual','monthly','weekly','daily')),
  start_at timestamptz not null default now(),
  expires_at timestamptz,
  paid boolean not null default false,
  payment_method text check (payment_method in ('cash','card','installment')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  member_id uuid not null references public.members(id) on delete cascade,
  amount integer not null check (amount >= 0),
  method text not null check (method in ('cash','card','installment')),
  status text not null default 'paid' check (status in ('paid','unpaid','refunded')),
  paid_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references auth.users(id) on delete set null,
  action text not null,
  member_no text,
  created_at timestamptz not null default now()
);

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin') $$;

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles(id, role) values (new.id, 'member')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end;
$$;
drop trigger if exists members_touch_updated_at on public.members;
create trigger members_touch_updated_at before update on public.members
for each row execute procedure public.touch_updated_at();

alter table public.profiles enable row level security;
alter table public.members enable row level security;
alter table public.payments enable row level security;
alter table public.audit_logs enable row level security;

drop policy if exists "profiles read self or admin" on public.profiles;
create policy "profiles read self or admin" on public.profiles for select to authenticated
using (id = auth.uid() or public.is_admin());

drop policy if exists "members admin all" on public.members;
create policy "members admin all" on public.members for all to authenticated
using (public.is_admin()) with check (public.is_admin());

drop policy if exists "members read own" on public.members;
create policy "members read own" on public.members for select to authenticated
using (auth_user_id = auth.uid());

drop policy if exists "payments admin all" on public.payments;
create policy "payments admin all" on public.payments for all to authenticated
using (public.is_admin()) with check (public.is_admin());

drop policy if exists "payments read own" on public.payments;
create policy "payments read own" on public.payments for select to authenticated
using (exists (select 1 from public.members m where m.id = member_id and m.auth_user_id = auth.uid()));

drop policy if exists "audit admin read" on public.audit_logs;
create policy "audit admin read" on public.audit_logs for select to authenticated
using (public.is_admin());

-- Members cannot self-assign admin: profiles has no client insert/update policy.
-- Assign the first trusted admin manually from SQL Editor as documented in README.
