# 會員管理雲端網站（Next.js + Supabase）

這是一份可部署的正式網站起始專案，包含：
- Supabase Email/Password 登入
- 管理員 / 會員角色
- 會員資料新增、編輯、刪除
- 五種會籍方案與期限計算
- 付款狀態及付款方式
- Code 128 條碼、QR Code
- 條碼輸入驗證及手機相機掃描
- 繁體中文 / English 切換
- Supabase RLS 資料存取政策

## 重要
下載後仍需建立 Supabase 專案、執行 `supabase/schema.sql`、設定環境變數並部署到 Vercel。
沒有完成這些步驟前，網站不會有跨裝置雲端同步。請勿將 `SUPABASE_SERVICE_ROLE_KEY` 放進 `NEXT_PUBLIC_` 變數或公開給任何人。

## 1. 安裝
需要 Node.js 20 或更新版本。

```bash
npm install
cp .env.example .env.local
npm run dev
```

## 2. 設定 Supabase
1. 在 Supabase 建立專案。
2. 開啟 SQL Editor，貼上 `supabase/schema.sql` 並執行。
3. 到 Project Settings → API，複製 Project URL 和 anon/public key。
4. 填入 `.env.local`：
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`

## 3. 建立第一位管理員
1. 在網站註冊一個帳號並完成 Email 確認（若專案要求）。
2. 在 Supabase SQL Editor 執行以下 SQL，將該帳號設為管理員：
```sql
update public.profiles
set role = 'admin'
where id = (select id from auth.users where email = '你的登入Email');
```
將 `你的登入Email` 換成實際註冊 Email。請只對可信任的管理員帳號執行。

## 4. 部署
建議使用 Vercel：
1. 將專案資料夾上傳到自己的 GitHub repository。
2. 在 Vercel 匯入該 repository。
3. 在 Vercel Project Settings → Environment Variables 設定上述兩個 Supabase 變數。
4. Deploy。

部署後，Supabase Authentication → URL Configuration 的 Site URL 設為正式網站網址，並將正式網址加入 Redirect URLs。

## 5. 會員登入帳號
目前管理後台可建立會員資料，但不會在前端替會員建立 Auth 帳號（避免把管理密鑰暴露在瀏覽器）。
會員需自行使用註冊頁建立登入帳號；管理員可在 Supabase 的 profiles / members 將該會員帳號與會員資料關聯。正式營運若要由管理員發送邀請，應再加上使用 Supabase server-side Admin API 的安全邀請 API。

## 6. 方案
- 終身：NT$20,000（永久）
- 年繳：NT$2,000（365 天）
- 月繳：NT$200（30 天）
- 週繳：NT$100（7 天）
- 日繳：NT$50（24 小時）

## 安全提醒
- 啟用 Email 確認及適當密碼政策。
- 管理員帳號啟用 MFA。
- 定期匯出備份；免費方案的備份與可用性限制需自行評估。
- 正式營運前請在測試專案驗證 RLS、登入、付款與刪除流程。
