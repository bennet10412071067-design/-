import "./globals.css";
import type { Metadata } from "next";
export const metadata: Metadata = { title: "會員管理中心", description: "會員管理與條碼驗證系統" };
export default function RootLayout({ children }: Readonly<{children: React.ReactNode}>) {
  return <html lang="zh-Hant"><body>{children}</body></html>;
}
