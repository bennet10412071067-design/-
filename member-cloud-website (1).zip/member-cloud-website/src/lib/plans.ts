export const plans = {
  lifetime: { zh: "終身", en: "Lifetime", price: 20000, days: null },
  annual: { zh: "年繳", en: "Annual", price: 2000, days: 365 },
  monthly: { zh: "月繳", en: "Monthly", price: 200, days: 30 },
  weekly: { zh: "週繳", en: "Weekly", price: 100, days: 7 },
  daily: { zh: "日繳", en: "Daily", price: 50, days: 1 }
} as const;

export type PlanKey = keyof typeof plans;

export function expiryFrom(plan: PlanKey, start = new Date()) {
  if (plan === "lifetime") return null;
  const d = new Date(start);
  d.setDate(d.getDate() + plans[plan].days!);
  return d.toISOString();
}

export function memberStatus(expiry: string | null, paid: boolean) {
  if (!paid) return "unpaid";
  if (!expiry) return "valid";
  return new Date(expiry).getTime() > Date.now() ? "valid" : "expired";
}
