"use client";
import { useEffect, useMemo, useState } from "react";
import { supabaseBrowser } from "@/lib/supabase";
import { plans, PlanKey, expiryFrom, memberStatus } from "@/lib/plans";
import { QRCodeSVG } from "qrcode.react";
import JsBarcode from "jsbarcode";
import { BrowserMultiFormatReader } from "@zxing/browser";

type Member = {
  id:string; member_no:string; name:string; phone:string; birth_date:string|null;
  plan:PlanKey; start_at:string; expires_at:string|null; paid:boolean;
  payment_method:string|null; auth_user_id:string|null; created_at:string;
};
const s = supabaseBrowser();

export default function Home() {
  const [user,setUser] = useState<any>(null);
  const [role,setRole] = useState("member");
  const [lang,setLang] = useState<"zh"|"en">("zh");
  const [email,setEmail] = useState(""); const [password,setPassword] = useState("");
  const [members,setMembers] = useState<Member[]>([]);
  const [selected,setSelected] = useState<Member|null>(null);
  const [search,setSearch] = useState(""); const [scan,setScan] = useState("");
  const [message,setMessage] = useState(""); const [error,setError] = useState("");
  const [form,setForm] = useState({name:"",phone:"",birth_date:"",plan:"monthly" as PlanKey,paid:false,payment_method:"cash"});
  const [editing,setEditing] = useState<string|null>(null);
  const [cameraControls,setCameraControls] = useState<{stop:()=>void}|null>(null);
  const t = (zh:string,en:string)=>lang==="zh"?zh:en;

  async function load() {
    const {data:{user:u}} = await s.auth.getUser();
    setUser(u);
    if (!u) return;
    const {data:p} = await s.from("profiles").select("role").eq("id",u.id).maybeSingle();
    setRole(p?.role || "member");
    const {data, error:e} = await s.from("members").select("*").order("created_at",{ascending:false});
    if(e) setError(e.message); else setMembers((data||[]) as Member[]);
  }
  useEffect(()=>{ load(); const {data:{subscription}}=s.auth.onAuthStateChange(()=>{load()}); const interval=setInterval(()=>{if(document.visibilityState==="visible")load();},15000); return ()=>{subscription.unsubscribe();clearInterval(interval);};},[]);

  async function signIn(e:React.FormEvent){e.preventDefault();setError("");const {error}=await s.auth.signInWithPassword({email,password});if(error)setError(error.message);else load();}
  async function signUp(e:React.FormEvent){e.preventDefault();setError("");const {error}=await s.auth.signUp({email,password});if(error)setError(error.message);else setMessage(t("註冊成功，請依郵件提示完成確認。","Registration submitted. Check your email to confirm."));}
  async function signOut(){await s.auth.signOut();setUser(null);setMembers([]);}
  async function save(e:React.FormEvent){
    e.preventDefault();setError("");setMessage("");
    if(!form.name.trim() || !/^[+\d()\s-]{8,20}$/.test(form.phone.trim()) || !form.birth_date){setError(t("請填寫姓名、有效手機號碼及完整出生日期。","Enter name, valid phone and full birth date."));return;}
    const old=members.find(m=>m.id===editing);
    const start=old && old.plan===form.plan?new Date(old.start_at):new Date();
    const payload={...form,name:form.name.trim(),phone:form.phone.trim(),birth_date:form.birth_date,start_at:start.toISOString(),expires_at:expiryFrom(form.plan,start),...(editing?{}:{member_no:`M${crypto.randomUUID().replace(/-/g,"").slice(0,14).toUpperCase()}`})};
    const q=editing?s.from("members").update(payload).eq("id",editing):s.from("members").insert(payload);
    const {error}=await q;
    if(error)setError(error.message);else{setMessage(t("會員資料已儲存","Member saved"));setEditing(null);setForm({name:"",phone:"",birth_date:"",plan:"monthly",paid:false,payment_method:"cash"});await load();}
  }
  async function remove(m:Member){
    if(!confirm(t(`確定刪除會員「${m.name}」（${m.member_no}）？此動作無法復原。`,`Delete ${m.name} (${m.member_no})? This cannot be undone.`)))return;
    const {error}=await s.from("members").delete().eq("id",m.id);
    if(error)setError(error.message);else{setMessage(t("會員資料已刪除","Member deleted"));await load();}
  }
  function edit(m:Member){setEditing(m.id);setForm({name:m.name,phone:m.phone,birth_date:m.birth_date||"",plan:m.plan,paid:m.paid,payment_method:m.payment_method||"cash"});}
  const visible=useMemo(()=>members.filter(m=>(m.name+" "+m.phone+" "+m.member_no).toLowerCase().includes(search.toLowerCase())),[members,search]);
  const myMember=members.find(m=>m.auth_user_id===user?.id);
  function showBarcode(value:string){
    if(typeof window==="undefined")return;
    const canvas=document.getElementById("barcode") as HTMLCanvasElement|null;
    if(canvas && value) JsBarcode(canvas,value,{format:"CODE128",displayValue:true,width:2,height:65,margin:8});
  }
  useEffect(()=>{if(selected)showBarcode(selected.member_no);else if(myMember)showBarcode(myMember.member_no)},[selected,members,user]);
  async function checkCode(code:string){
    const value=code.trim();if(!value)return;
    const {data:m,error:e}=await s.from("members").select("name,member_no,paid,expires_at").eq("member_no",value).maybeSingle();
    if(e){setError(e.message);return;}
    if(!m){setMessage(t("查無會員","Member not found"));return;}
    const st=memberStatus(m.expires_at,m.paid);
    setMessage(`${m.name} (${m.member_no})：${t(st==="valid"?"有效":st==="expired"?"已到期":"尚未付款",st==="valid"?"Valid":st==="expired"?"Expired":"Unpaid")}`);
  }
  async function cameraScan(){
    setError("");
    try{
      const devices=await BrowserMultiFormatReader.listVideoInputDevices();
      if(!devices.length)throw new Error(t("找不到相機","No camera found"));
      const video=document.getElementById("scanner-video") as HTMLVideoElement;
      const reader=new BrowserMultiFormatReader();
      const controls=await reader.decodeFromVideoDevice(devices[0].deviceId,video,(result)=>{
        if(result){setScan(result.getText());void checkCode(result.getText());}
      });
      setCameraControls(controls);
    }catch(e:any){setError(e.message||"Camera error");}
  }
  function verify(){void checkCode(scan);}
  if(!user)return <main className="shell"><div className="panel auth"><div className="top"><h1>{t("會員管理中心","Member Portal")}</h1><button className="secondary" onClick={()=>setLang(lang==="zh"?"en":"zh")}>{lang==="zh"?"EN":"中文"}</button></div><form onSubmit={signIn}><div className="field"><label>Email</label><input type="email" value={email} onChange={e=>setEmail(e.target.value)} required/></div><div className="field"><label>{t("密碼","Password")}</label><input type="password" value={password} onChange={e=>setPassword(e.target.value)} minLength={8} required/></div><button type="submit">{t("登入","Sign in")}</button> <button type="button" className="secondary" onClick={signUp}>{t("建立帳號","Sign up")}</button></form>{error&&<p className="error">{error}</p>}{message&&<p className="success">{message}</p>}<p className="muted">{t("請使用 Email 與至少 8 碼密碼。","Use your email and a password of at least 8 characters.")}</p></div></main>;
  return <main className="shell">
    <header className="top"><div><h1>{t("會員管理中心","Member Management")}</h1><div className="muted">{user.email} · {role==="admin"?t("管理員","Admin"):t("會員","Member")}</div></div><div className="row"><button className="secondary" onClick={()=>setLang(lang==="zh"?"en":"zh")}>{lang==="zh"?"English":"繁體中文"}</button><button className="secondary" onClick={load}>{t("重新同步","Refresh")}</button><button onClick={signOut}>{t("登出","Sign out")}</button></div></header>
    {error&&<p className="error">{error}</p>}{message&&<p className="success">{message}</p>}
    {role==="admin"?<>
      <div className="grid"><section className="panel"><div className="muted">{t("會員總數","Total members")}</div><div className="stats">{members.length}</div></section><section className="panel"><div className="muted">{t("有效會員","Active members")}</div><div className="stats">{members.filter(m=>memberStatus(m.expires_at,m.paid)==="valid").length}</div></section><section className="panel"><div className="muted">{t("未付款","Unpaid")}</div><div className="stats">{members.filter(m=>!m.paid).length}</div></section></div>
      <section className="panel"><h2>{editing?t("編輯會員","Edit member"):t("新增會員","Add member")}</h2><form onSubmit={save}><div className="grid"><div className="field"><label>{t("姓名","Name")}</label><input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/></div><div className="field"><label>{t("手機","Mobile")}</label><input required value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})}/></div><div className="field"><label>{t("出生日期","Date of birth")}</label><input type="date" required max={new Date().toISOString().slice(0,10)} value={form.birth_date} onChange={e=>setForm({...form,birth_date:e.target.value})}/></div><div className="field"><label>{t("會員方案","Plan")}</label><select value={form.plan} onChange={e=>setForm({...form,plan:e.target.value as PlanKey})}>{Object.entries(plans).map(([k,p])=><option key={k} value={k}>{t(p.zh,p.en)} — NT${p.price.toLocaleString()}</option>)}</select></div><div className="field"><label>{t("付款方式","Payment method")}</label><select value={form.payment_method} onChange={e=>setForm({...form,payment_method:e.target.value})}><option value="cash">{t("現金","Cash")}</option><option value="card">{t("現場刷卡","In-person card")}</option><option value="installment">{t("分期付款","Installments")}</option></select></div><div className="field"><label>{t("付款狀態","Payment status")}</label><select value={String(form.paid)} onChange={e=>setForm({...form,paid:e.target.value==="true"})}><option value="false">{t("未付款","Unpaid")}</option><option value="true">{t("已付款","Paid")}</option></select></div></div><div className="row"><button type="submit">{t("儲存會員","Save member")}</button>{editing&&<button type="button" className="secondary" onClick={()=>{setEditing(null);setForm({name:"",phone:"",birth_date:"",plan:"monthly",paid:false,payment_method:"cash"});}}>{t("取消編輯","Cancel")}</button>}</div></form></section>
      <section className="panel"><div className="top"><h2>{t("會員名單","Members")}</h2><input style={{maxWidth:280}} placeholder={t("搜尋姓名、手機或編號","Search name, phone or ID")} value={search} onChange={e=>setSearch(e.target.value)}/></div><div className="tablewrap"><table><thead><tr><th>{t("會員編號","Member ID")}</th><th>{t("姓名","Name")}</th><th>{t("手機","Mobile")}</th><th>{t("方案","Plan")}</th><th>{t("到期日","Expiry")}</th><th>{t("狀態","Status")}</th><th>{t("操作","Actions")}</th></tr></thead><tbody>{visible.map(m=><tr key={m.id}><td>{m.member_no}</td><td>{m.name}</td><td>{m.phone}</td><td>{t(plans[m.plan].zh,plans[m.plan].en)}</td><td>{m.expires_at?new Date(m.expires_at).toLocaleDateString():"永久"}</td><td><span className="tag">{memberStatus(m.expires_at,m.paid)}</span></td><td><div className="row"><button className="secondary" onClick={()=>setSelected(m)}>{t("卡片","Card")}</button><button className="secondary" onClick={()=>edit(m)}>{t("編輯","Edit")}</button><button className="danger" onClick={()=>remove(m)}>{t("刪除","Delete")}</button></div></td></tr>)}</tbody></table></div></section>
      <section className="panel"><h2>{t("條碼驗證","Barcode verification")}</h2><div className="row"><input placeholder={t("掃描器輸入會員編號","Scan or enter member ID")} value={scan} onChange={e=>setScan(e.target.value)} onKeyDown={e=>e.key==="Enter"&&verify()}/><button onClick={verify}>{t("驗證","Verify")}</button><button className="secondary" onClick={cameraScan} disabled={!!cameraControls}>{t("開啟相機","Open camera")}</button>{cameraControls&&<button className="secondary" onClick={()=>{cameraControls.stop();setCameraControls(null);}}>{t("關閉相機","Stop camera")}</button>}</div><video id="scanner-video" style={{width:"100%",maxWidth:360,marginTop:12}} muted playsInline/><p className="muted">{message}</p></section>
    </>:<section className="panel"><h2>{t("我的會員資料","My membership")}</h2>{myMember? <div className="membercard"><h3>{myMember.name}</h3><p>{myMember.member_no}</p><p>{t(plans[myMember.plan].zh,plans[myMember.plan].en)} · NT${plans[myMember.plan].price}</p><p>{t("付款","Payment")}: {myMember.paid?t("已付款","Paid"):t("未付款","Unpaid")}</p><p>{t("到期日","Expires")}: {myMember.expires_at?new Date(myMember.expires_at).toLocaleDateString():t("永久","Lifetime")}</p><canvas id="barcode"/><QRCodeSVG value={myMember.member_no} size={120}/></div>:<p>{t("目前尚未連結會員資料，請聯絡管理員。","No membership record is linked. Please contact an administrator.")}</p>}</section>}
    {selected&&<div className="panel"><div className="top"><h2>{t("會員卡","Membership card")}</h2><button className="secondary" onClick={()=>setSelected(null)}>{t("關閉","Close")}</button></div><div className="membercard"><h3>{selected.name}</h3><p>{selected.member_no}</p><p>{t(plans[selected.plan].zh,plans[selected.plan].en)}</p><canvas id="barcode"/><QRCodeSVG value={selected.member_no} size={120}/></div><button className="secondary" onClick={()=>window.print()}>{t("列印會員卡","Print card")}</button></div>}
  </main>;
}
